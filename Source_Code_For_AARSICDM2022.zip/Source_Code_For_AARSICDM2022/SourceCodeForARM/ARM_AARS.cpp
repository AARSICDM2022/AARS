#include <iostream>
#include <chrono>
#include "AARSCounter.hpp"
#include <vector>
#include "cxxopts.hpp"
#include "csv.hpp"
#include <string>
#include <fstream>
#include <sstream>
//#include <direct.h>
#include <numeric>

struct SupCall {
    // called by query engine before processing the stream
    // engine passes ri, i.e. the number of states of Xi, 
    // and qi, the number of states parents of Xi MAY assume
    void init(int ri, int qi) { count = 0; }

    // called by query engine after processing of the stream is done
    // engine passes qi, the ACTUAL number of states
    // that parents of Xi assumed
    void finalize(int qi,int m1) { }

    void operator()(int Nij) {
        //std::cout << "call from CQE with Nij=" << Nij << std::endl;
        count=Nij;
    } // operator()

    void operator()(int Nijk, int Nij) {
        //std::cout << "call from CQE with Nijk=" << Nijk << std::endl;
        count=Nijk;
    } // operator()

    // access to internal state (return value is specified by user)
    int support() const { return count; }

    // user specified internal state
    int count = 0;
}; // struct support call

struct ConfCall {
    // called by query engine before processing the stream
    // engine passes ri, i.e. the number of states of Xi, 
    // and qi, the number of states parents of Xi MAY assume
    void init(int ri, int qi) { cval = 0; }

    // called by query engine after processing of the stream is done
    // engine passes qi, the ACTUAL number of states
    // that parents of Xi assumed
    void finalize(int qi,int m1) { }

    void operator()(int Nij) {
        //std::cout << "call from CQE with Nij=" << Nij << std::endl;
        //count=Nij;
    } // operator()

    void operator()(int Nijk, int Nij) {
        //std::cout << "call from CQE with Nijk=" << Nijk << std::endl;
        cval=static_cast<double>(Nijk)/Nij;
    } // operator()

    // access to internal state (return value is specified by user)
    int confidence() const { return cval; }

    // user specified internal state
    double cval = 0;
}; // struct Confidence call

int main(int argc, char* argv[]) {

const int N = 1;
int n = -1;
int m = -1;
using data_type = uint8_t;
    std::string Data_Name=argv[1];
    std::string No_d_ins=argv[2];     
    std::string csv_name="datafolder/"+Data_Name+"_"+ No_d_ins +"_binarized.csv";
    std::vector<data_type> D; bool b = false;
    std::tie(b, n, m) = read_csv(csv_name, D);  
//--------------------------------------------------------------------------------------------------------------
std::cout<<"AARS is being built"<<std::endl;
    std::vector<double>Build_Time_Diff; std::vector<double>Time_perRun_Diff;
    auto Build_start = std::chrono::steady_clock::now();
    AARSCounter<1> AARS = create_AARSCounter<1>(n, m, std::begin(D));
    auto Build_end = std::chrono::steady_clock ::now(); 
    Build_Time_Diff.push_back(std::chrono::duration_cast<std::chrono::microseconds>(Build_end-Build_start).count()); 
std::cout<<"Building of the AARS is done"<<std::endl;
//--------------------------------------------------------------------------------------------------------------

    for (int ArmRun = 0; ArmRun < 1; ArmRun++)
    {
     auto Rtime_start = std::chrono::steady_clock::now();

/*--------------------------------- Candidate itemset generations-------------------------------------------------------------------*/
// finding 1 kth items which satisfy minmum support threshold.
    std::vector<std::vector<int>>Itemsets;double MinSupport=std::stod(argv[3]); double minConfidence = std::stod(argv[4]);
    std::vector<int>Paset,tempitem; std::vector<data_type>State_Pa; std::vector<SupCall> SupportVal(1);
            for (int itemid=0;itemid<n;itemid++){
                Paset.clear();Paset.push_back(itemid);
                State_Pa.clear();State_Pa.push_back(1);
                SupportVal[0].init(1,1); tempitem.clear();
                AARS.apply(Paset,State_Pa,SupportVal);
                double tempsup=static_cast<double>( SupportVal[0].support()) / m;
                if ( tempsup>=MinSupport){
                    tempitem.push_back(itemid);
                    Itemsets.push_back(tempitem);
                }
            }
            // finding kth itemsets which satisfy minmum support threshold.
            int Kth=2;
            while (Itemsets.size()>1 && Kth<=7)    
            {
                std::vector<std::vector<int>>MidItemsets; std::vector<data_type>State_tempitem;
                for (int itemidi = 0; itemidi <Itemsets.size()-1 ; itemidi++)
                {
                    for (int itemidj = itemidi+1; itemidj <Itemsets.size() ; itemidj++)
                    {
                        tempitem.clear(); tempitem.insert(tempitem.end(),Itemsets[itemidi].begin(),Itemsets[itemidi].end()); 
                        tempitem.insert(tempitem.end(),Itemsets[itemidj].begin(),Itemsets[itemidj].end());
                        std::sort(tempitem.begin(),tempitem.end());
                        tempitem.erase(std::unique(tempitem.begin(),tempitem.end()),tempitem.end());
                        if(tempitem.size()!= Kth && Itemsets.size()>2){continue;}
                        State_tempitem.clear(); State_tempitem.resize(tempitem.size(),1); 
                        SupportVal[0].init(1,1);
                        AARS.apply(tempitem,State_tempitem,SupportVal);
                        double tempsup=static_cast<double>( SupportVal[0].support()) / m;
                        if ( tempsup>=MinSupport){             
                        MidItemsets.push_back(tempitem) ;          
                        }
                    }        
                }
                std::sort(MidItemsets.begin(),MidItemsets.end());
                MidItemsets.erase(std::unique(MidItemsets.begin(),MidItemsets.end()),MidItemsets.end());
                if (MidItemsets.empty()){break;}
                Itemsets=MidItemsets;
                Kth=Kth+1;
            }
std::cout<<"Total Itemstes="<<Itemsets.size()<<std::endl;
std::cout<< "Itemsets Searching is done"<<std::endl;
/*--------------------------------------------------------------------------------------------------------------------------*/
/*--------------------------------Rule generation from frequent itemsets-----------------------------------------------------*/
/*--------------------------------------------------------------------------------------------------------------------------*/
std::cout<< "Rule Searching is started"<<std::endl;
   std::vector<std::vector<int>>FinalAntecedence,FinalConsequent; 
            std::vector<int>Antecedence,Consequent; 
            std::vector<data_type>State_Antecedence,State_Consequent;
            std::vector<ConfCall> ConfidenceVal(1);
            for (int i = 0; i < Itemsets.size(); i++)
            {
		if(Itemsets[i].size()<4){continue;}
                for (int j = 0; j < Itemsets[i].size(); j++)
                {
                    Consequent.push_back(Itemsets[i][j]); 
                    for (int k = 0; k < Itemsets[i].size(); k++)
                    {
                        if (k!=j)
                        {
                            Antecedence.push_back(Itemsets[i][k]);
                        }                
                    }
                    State_Antecedence.resize(Antecedence.size(),1);
                    State_Consequent.resize(Consequent.size(),1);
                    ConfidenceVal[0].init(1,1);
                    AARS.apply(Antecedence,State_Antecedence,Consequent,State_Consequent,ConfidenceVal);
                    double tempconfid=ConfidenceVal[0].confidence();
                    if (tempconfid>=minConfidence){
                        FinalAntecedence.push_back(Antecedence);
                        FinalConsequent.push_back(Consequent);
                    }
                    Consequent.clear(); Antecedence.clear();
                }        
            }    
std::cout<<"Total rules="<<FinalAntecedence.size()<<std::endl;
std::cout<< "Rule Searching is done"<<std::endl;

    
    auto Rtime_end = std::chrono::steady_clock::now();
    Time_perRun_Diff.push_back(std::chrono::duration_cast<std::chrono::microseconds>(Rtime_end-Rtime_start).count());
    }
std::cout<< "Execution Time  is being writen in file"<<std::endl;
    std::string ARM_Run_Time="output/ARM/AARS/"+Data_Name+"_"+No_d_ins+"_ARM_time.csv";
    std::ofstream runtimefile(ARM_Run_Time);
	
	if (runtimefile.is_open())
    {	runtimefile << Build_Time_Diff[0];
		runtimefile<< ",";
        //myfile51 << str ;
        for(int tV=0;tV<Time_perRun_Diff.size();++tV){
        runtimefile << Time_perRun_Diff[tV];
        runtimefile<< ",";
        }
        runtimefile<<"\n";
    }
	runtimefile.close();
    return 0;
} // main
