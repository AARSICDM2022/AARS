#!/bin/bash

if [ -n "$1" ]; then
  DIR="$1"
else
  DIR=`pwd`
fi

mkdir -p build/
rm -rf build/*
cd build/
cmake ../ -DCMAKE_CXX_COMPILER=/usr/bin/g++
cmake ../ -DCMAKE_INSTALL_PREFIX=$DIR
cmake ../ -DCMAKE_BUILD_TYPE=Debug
make -j8 install
#make -j8 install VERBOSE=1
