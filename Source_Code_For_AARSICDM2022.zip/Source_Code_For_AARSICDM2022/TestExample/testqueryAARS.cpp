#include <iostream>
#include <chrono>
#include "AARSCounter.hpp"
#include <vector>
#include "cxxopts.hpp"
#include "csv.hpp"
#include <string>
#include <fstream>
#include <sstream>
//#include <direct.h>
#include <numeric>

struct call {
    // called by query engine before processing the stream
    // engine passes ri, i.e. the number of states of Xi, 
    // and qi, the number of states parents of Xi MAY assume
    void init(int ri, int qi) { count = 0; }

    // called by query engine after processing of the stream is done
    // engine passes qi, the ACTUAL number of states
    // that parents of Xi assumed
    void finalize(int qi,int m1) { }

    void operator()(int Nij) {
        std::cout << "call from CQE with Nij=" << Nij << std::endl;
    } // operator()

    void operator()(int Nijk, int Nij) {
        std::cout << "call from CQE with Nijk=" << Nijk << std::endl;
        count++;
    } // operator()

    // access to internal state (return value is specified by user)
    int score() const { return count; }

    // user specified internal state
    int count = 0;
}; // struct call


int main(int argc, char* argv[]) {

const int N = 1;
int n = -1;
int m = -1;
using data_type = uint8_t;
    std::string No_d_ins="1K";   // put row size of the data for accessing data.
    std::string Data_Name="alarm"; // put data name
    std::string csv_name="datafolder/"+Data_Name+"_"+ No_d_ins +".csv";
    std::vector<data_type> D; bool b = false;
    std::tie(b, n, m) = read_csv(csv_name, D);  
 //--------------------------------------------------------------------------------------------------------------
    std::vector<double>Build_Time_Diff; std::vector<double>Time_perQuery_Diff;

    auto Build_start = std::chrono::steady_clock::now();
    AARSCounter<N,data_type> AARS = create_AARSCounter<1>(n, m, std::begin(D));
    auto Build_end = std::chrono::steady_clock ::now(); 
    Build_Time_Diff.push_back(std::chrono::duration_cast<std::chrono::microseconds>(Build_end-Build_start).count()); 
    std::vector<int>Paset{15,7,33,32,10,35,6,30,8,29,31,36,9,12};
    //std::vector<data_type>State_Pa{1,0,2,1}; // set parents' states
    std::vector<int>xiset{25};
    //std::vector<data_type>State_xi{1}; // set child state. 
    std::vector<call> C(1); 
    bool ShowAll=1; // want to see all enumaration fount in the dataset; please set "ShowAll=1" otherwise "ShowAll=0";
    auto Qtime_start = std::chrono::steady_clock::now();
    //AARS.apply(Paset,State_Pa,C);
    
   // AARS.apply(Paset,C,ShowAll);
     //AARS.apply(Paset,xiset,C,ShowAll);
    AARS.apply(Paset,xiset,C);
     //AARS.apply(Paset,State_Pa,xiset,State_xi,C); // want to see only one statewise enumaration please set state value of parent and child before uncomment this line. 
    // AARS.apply(Paset,State_Pa,C);
    //  AARS.apply(xiset,C,ShowAll);
    auto Qtime_end = std::chrono::steady_clock::now();
    Time_perQuery_Diff.push_back(std::chrono::duration_cast<std::chrono::microseconds>(Qtime_end-Qtime_start).count());
    return 0;
} // main