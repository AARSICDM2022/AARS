#!/bin/bash

Dname="alarm"
Dsize="1K"

start=`date +%s`
      /usr/bin/time -v bin/BNSL_AARS $Dname $Dsize  
#     /usr/bin/time -v bin/BNSL_ADT $Dname $Dsize
#     /usr/bin/time -v bin/BNSL_BMAP $Dname $Dsize
#     /usr/bin/time -v bin/BNSL_RAD $Dname $Dsize
	echo Execution on $Dname $Dsize is done
end=`date +%s`
runtime=$((end-start))
echo Total time is spent $runtime seconds.
echo All done