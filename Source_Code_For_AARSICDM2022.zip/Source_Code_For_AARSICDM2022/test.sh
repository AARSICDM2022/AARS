#!/bin/bash

bin/Query

