#include <algorithm>
#include <iostream>
#include <vector>
#include <tuple>
#include <chrono>
#include<string>
#include<fstream>
#include<sstream>
#include "bit_util.hpp"
#include "csv.hpp"
#include "ADTree.hpp"
#include "BVCounter.hpp"
//#include <direct.h>
#include <numeric>

struct call {
// called by query engine before processing the stream
// engine passes ri, i.e. the number of states of Xi,
// and qi, the number of states parents of Xi MAY assume
void init(int ri, int qi) { count = 0; }

// called by query engine after processing of the stream is done
// engine passes qi, the ACTUAL number of states
// that parents of Xi assumed
void finalize(int qi,int m1) { }

void operator()(int Nij) {
    //std::cout << "call from CQE with Nij=" << Nij << std::endl;
} // operator()

void operator()(int Nijk, int Nij) {
  //std::cout << "call from CQE with Nijk=" << Nijk << std::endl;
count++;
} // operator()

// access to internal state (return value is specified by user)
int score() const { return count; }

// user specified internal state
int count = 0;
}; // struct call


int main(int argc, char* argv[]) {
    const int N = 2;
    int n = -1;
    int m = -1;
    using data_type = uint8_t;
    std::string Data_Name=argv[1];
    std::string No_d_ins=argv[2];
    std::string No_d_var=argv[3];
    std::string csv_name="datafolder/"+Data_Name+"_"+ No_d_ins +".csv";
    std::vector<data_type> D; bool b = false;
    std::tie(b, n, m) = read_csv(csv_name, D);
    //--------------------------------------------------------------------------------------------------------------
    std::vector<double>Build_Time_Diff;Build_Time_Diff.reserve(1);
    int NoRun=1; double alpha = 1.0;
    auto Build_start = std::chrono::steady_clock::now();
    ADTree<N, data_type> adt(m, n, m, D);
    adt.build_tree();
    auto Build_end = std::chrono::steady_clock ::now();
    Build_Time_Diff.push_back(std::chrono::duration_cast<std::chrono::microseconds>(Build_end-Build_start).count());

    //std::string csv_name_query_result_1="output/ADT/"+Data_Name+"_"+No_d_ins+"_Build_time_v_"+ No_d_var +".csv";
	std::string csv_name_query_result_1="output/RANDOM/ADT/"+Data_Name+"_"+No_d_ins+"_Build_time.csv";
    std::ofstream buildtimefile (csv_name_query_result_1);
    // build time writting in the file
    if (buildtimefile.is_open()){
        //  myfile6 << str ;
        for(int tV=0;tV<Build_Time_Diff.size();++tV){
            buildtimefile << Build_Time_Diff[tV];
            buildtimefile<< ",";
        }
        buildtimefile<<"\n";
    }
    Build_Time_Diff.clear();
    buildtimefile.close();
    // -----------------------------loading queries----------------------------------------------------------------
    //std::string csv_name_query="queryfolder/Q"+Data_Name+"_qv"+ No_d_var +".txt";
	std::string csv_name_query="queryfolder/Q"+Data_Name+".txt";
    std::ifstream file(csv_name_query);
    std::string str;  int qno=0;
    //std::string csv_name_query_result_2="output/ADT/"+Data_Name+"_"+No_d_ins+"_Query_time_v_"+ No_d_var +".csv";
	std::string csv_name_query_result_2="output/RANDOM/ADT/"+Data_Name+"_"+No_d_ins+"_Query_time.csv";
    std::ofstream runtimefile(csv_name_query_result_2);

    while ((std::getline(file, str)) && (qno < 100000)) {
        std::istringstream iss(str);
        std::vector<std::string> qD;
        std::vector<int> xiset;
        std::vector<int> Paset;
        do{
            std::string subs;
            iss>>subs;
            qD.push_back(subs);
        }while(iss);

        for(int qi=0;qi<qD.size()-1;++qi){
            if(qi==qD.size()-2){
                int ChSubs1 = std::stoi(qD[qi].c_str());
                xiset.push_back(ChSubs1);
            }
            else{
                int ChSubs1 = std::stoi(qD[qi].c_str());
                Paset.push_back(ChSubs1);
            }
        }
        std::vector<call> C(xiset.size()); std::vector<double>Time_perQuery_Diff;Time_perQuery_Diff.reserve(NoRun); double avgeragetime=0;

        for(int run = 0 ; run<NoRun;++run){
            auto Qtime_start = std::chrono::steady_clock::now();
            adt.apply(xiset,Paset,C);
            auto Qtime_end = std::chrono::steady_clock::now();
            Time_perQuery_Diff.push_back(std::chrono::duration_cast<std::chrono::microseconds>(Qtime_end-Qtime_start).count());
            avgeragetime=avgeragetime+Time_perQuery_Diff[run];
        }
        //std::cout<< "Query"<<qno<<"done"<<std::endl;
        // Query time writtng in the file
        if (runtimefile.is_open()){
            for(int tV=0;tV<Time_perQuery_Diff.size();++tV){
                runtimefile << Time_perQuery_Diff[tV];
                runtimefile<< ",";
            }
            runtimefile<< ",";
            runtimefile << avgeragetime/NoRun;
            runtimefile<<"\n";
        }
        ++qno;
    }
    runtimefile.close();
    return 0;
} // main
