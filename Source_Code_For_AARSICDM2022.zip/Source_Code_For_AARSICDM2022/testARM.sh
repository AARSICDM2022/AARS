#!/bin/bash

Dname="alarm"
Dsize="1K"
MinSupport="0.20"
MinConfidence="0.30"
start=`date +%s`
	/usr/bin/time -v bin/ARM_AARS $Dname $Dsize $MinSupport $MinConfidence
#	/usr/bin/time -v bin/ARM_ADT $Dname $Dsize $MinSupport $MinConfidence
#	/usr/bin/time -v bin/ARM_BMAP $Dname $Dsize $MinSupport $MinConfidence
#	/usr/bin/time -v bin/ARM_RAD $Dname $Dsize $MinSupport $MinConfidence

#./ARMtestRunAARS $Dname $Dsize $MinSupport $MinConfidence
end=`date +%s`
runtime=$((end-start))
echo Total time is spent $runtime seconds.
echo done