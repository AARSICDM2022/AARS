#!/bin/bash
Dname="alarm"
Dsize="1K"
pasize=1
start=`date +%s`
for (( i = 1; i <= $pasize; i++ )) 
do 
 /usr/bin/time -v bin/RANDOM_AARS $Dname $Dsize "$i" 
# /usr/bin/time -v bin/RANDOM_ADT $Dname $Dsize "$i"
# /usr/bin/time -v bin/RANDOM_BMAP $Dname $Dsize "$i"
# /usr/bin/time -v bin/RANDOM_RAD $Dname $Dsize "$i"
	echo Execution on $Dname $Dsize $i is done
done
end=`date +%s`
runtime=$((end-start))
echo Total time is spent $runtime seconds.
echo All done