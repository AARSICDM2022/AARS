#include <iostream>
#include <chrono>
#include "AARSCounter.hpp"
#include "MDL.hpp"
#include <vector>
#include "cxxopts.hpp"
#include "csv.hpp"
#include <string>
#include <fstream>
#include <sstream>



int main(int argc, char* argv[]) {

    const int N = 0;
    int n = -1;
    int m = -1;
    using data_type = uint8_t;
    std::string Data_Name=argv[1];
    std::string No_d_ins=argv[2];
 std::string csv_name="datafolder/"+Data_Name+"_"+ No_d_ins +".csv";
    std::vector<data_type> D; bool b = false;
    std::tie(b, n, m) = read_csv(csv_name, D); 

    auto Build_start = std::chrono::steady_clock::now(); // recording start time of building query structure.
    AARSCounter<1> AARS = create_AARSCounter<1>(n, m, std::begin(D)); 
    auto Build_end = std::chrono::steady_clock ::now(); // recording  ending time of building query structure.
    std::vector<double> Build_Time_Diff;// declaration of variable for storing total time spend in building.
    Build_Time_Diff.push_back(std::chrono::duration_cast<std::chrono::microseconds>(Build_end-Build_start).count()); // total spend time for building of query structure.

    //----------------Bayesian network Learning-----------------------
    using set_type = AARSCounter<1>::set_type; using score_type = MDL::score_type;
    /*
    std::vector<int>xi1;xi1.resize(1);
    std::vector<int>pa1;pa1.resize(1);
    std::vector<int>xi2;
    std::vector<int>pa2;
    std::vector<MDL> F1(1);
    std::vector<MDL> F2(1);
    std::vector<int>CheckScore;
    xi1[0]=0;
    //pa1.push_back(24);
    for(int bn=0;bn<n;++bn){
    pa1[0]=bn;
    //xi2.push_back(12);
    //pa2.push_back(0);
    AARS.apply(pa1,xi1,F1); // AARS.apply(xi2,pa2,F2);
    auto ScoreCheck1=F1[0].score(); 
    CheckScore.push_back(ScoreCheck1.second);
}
*/
    //auto ScoreCheck2=F2[0].score();
std::vector<double> learn_Time_Diff;// declaration of variable for storing total time spend in learning. 
int LrnLimit=1;
for (int lrn=0; lrn< LrnLimit;++lrn){   
auto LearnTime_Start = std::chrono::steady_clock::now(); // recording start time of learning structure.
    
    std::vector<int>BayesNet;  
    BayesNet.assign(n*n,0);
    
    std::vector<int> BestPaSet;
    std::vector<int> BestPaSetSore;
     std::vector<int> Pa;
     
    
    double BayesNetScorePost=0; double LocalScore=std::numeric_limits<int>::max(); 
    double BayesNetScoreFinal=0; 
    score_type TmpScore;
    std::vector<int>::iterator bnit; int tPa=-1;
    
    for(int bni=0;bni<n;++bni){
        std::vector<int> BnXi;
        BnXi.push_back(bni);
        int MaxPaLimit=n;
        //int MaxPaLimit=RS.rm(bni);
        while (BestPaSet.size()<MaxPaLimit)
        {
            for(int bnj=0;bnj<n;++bnj){
                if (bni==bnj){continue;}
                bnit = std::find (BestPaSet.begin(), BestPaSet.end(), bnj);
                if(bnit!=BestPaSet.end()){continue;}
                BestPaSet.push_back(bnj);
                Pa=BestPaSet;
                std::vector<MDL> F(BnXi.size());
                AARS.apply(Pa,BnXi,F);
                TmpScore=F[0].score();
                if(LocalScore>TmpScore.first){
                    LocalScore=TmpScore.first;
                    tPa=bnj;
                    BestPaSet.pop_back();
                }
                else
                {
                    BestPaSet.pop_back();
                }
               
            }
            if (tPa>-1){
             BestPaSet.push_back(tPa);            
             tPa=-1;
            }
            else
            {
                LocalScore=std::numeric_limits<int>::max();  
                break; 
            }
            
        }

        for(int bnk=0; bnk < BestPaSet.size(); ++bnk){
            BayesNet[bni * n + BestPaSet[bnk]]=1;
        }
       // std::cout<< "Last paretn is " << BestPaSet.back() <<std::endl;
       
        BestPaSet.clear(); LocalScore=std::numeric_limits<int>::max(); 
    }
    
    for(int bni=0;bni<n;++bni){
        int pcount=0;
        int rmax=AARS.rm(bni);
        for(int bnj=0;bnj<n;++bnj){
            if (bni==bnj){continue;}
            if(BayesNet[bni * n + bnj]){
            std::vector<MDL>F1(1);
            AARS.apply(bnj,bni,F1);
            auto Score_1=F1[0].score();
            std::vector<MDL>F2(1);
            AARS.apply(bni,bnj,F2);
            auto Score_2=F2[0].score();
            if((Score_1.first) < (Score_2.first) ){
                BayesNet[bnj * n + bni]=0;
            }
            else
            {
                BayesNet[bni * n + bnj]=0;
            }
            pcount++;
            }
            //if(pcount==rmax){break;}
            
        }
    }

//-------------------------------------------------------------------------------------------------
auto LearnTime_Finish = std::chrono::steady_clock ::now(); // recording  ending time of learning structure.
    learn_Time_Diff.push_back(std::chrono::duration_cast<std::chrono::microseconds>(LearnTime_Finish-LearnTime_Start).count()); // total spend time for learning of  structure.
std::cout<< "Learning iteration = "<<lrn <<std::endl;
}
    std::string BNLearningTime="output/AARS/"+Data_Name+"_"+No_d_ins+"_BNL_time.csv";
    std::ofstream runtimefile(BNLearningTime);
	
	if (runtimefile.is_open())
    {	runtimefile << Build_Time_Diff[0];
		runtimefile<< ",";
        //myfile51 << str ;
        for(int tV=0;tV<learn_Time_Diff.size();++tV){
        runtimefile << learn_Time_Diff[tV];
        runtimefile<< ",";
        }
        runtimefile<<"\n";
    }
	runtimefile.close();
   /* 
    for(int bi=0; bi<5;++bi)
    {
            double BayesNetScorePre=0;//std::numeric_limits<int>::max(); 
            std::vector<int> xi ;
            std::vector<int> pa ;
            xi.push_back(bi);
        for(int bj=0; bj<5;++bj)
        {
            if(bi==bj){continue;}
            pa.push_back(bj);
            std::vector<MDL> F(xi.size());
            AARS.apply(pa,xi,F);
            TmpScore=F[0].score();
            if(BayesNetScorePre<TmpScore.second)
            {
                BayesNetScorePre= TmpScore.second;
            }
            else
            {
                pa.pop_back();
            }
        }   
        BayesNetScorePost= BayesNetScorePost + BayesNetScorePre;
        
        if(BayesNetScorePost>BayesNetScoreFinal)
        {
         BayesNetScoreFinal= BayesNetScorePost; 
         for (int bk=0; bk<pa.size();++bk)
         {
            int ind= bi*n+ pa[bk];
            BayesNet[ind]=1;
         }
        }
    }
    std::cout<<"Score is :" <<BayesNetScoreFinal<<std::endl;
    */

 /*  
    //---------------------Network writting in csv file
    std::string BayesianNetwork="C:/Users/Desktop/BayesianStructure.csv";
    std::ofstream BnNet (BayesianNetwork);
    for(int wti=0;wti<n; ++wti){
    if (BnNet.is_open())
    {
        //myfile5 << str ;
        for(int wtj=0;wtj<n;++wtj){
        
        BnNet <<BayesNet[wti*n+wtj] ;
        BnNet<< ",";
        }
        BnNet<<"\n";
    }
    }
    BnNet.close();
   */
   return 0;
}