#ifndef LIMITS_HPP
#define LIMITS_HPP

#include <limits>

constexpr double SABNA_DBL_INFTY = std::numeric_limits<double>::has_infinity ?
    std::numeric_limits<double>::infinity() : std::numeric_limits<double>::max();

#endif // LIMITS_HPP
