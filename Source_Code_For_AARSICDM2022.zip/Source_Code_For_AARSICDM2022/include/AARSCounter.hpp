
#ifndef AARS_COUNTER_HPP
#define AARS_COUNTER_HPP

#include <algorithm>
#include <cstdint>
#include <vector>
#include "bit_util.hpp"
#include "bitvector.hpp"


template <int N, typename Data = uint8_t> class AARSCounter {
public:
    using set_type = uint_type<N>;
    using data_type = Data;
    using pair_data_type = std::pair<data_type, data_type>;
    using pair_int = std::pair<int, int>;

    int n() const { return n_; }

    int m() const { return m_; }
    int rm(int XiVar) const { return r_[XiVar]; }
    
     //----------------------------------------------------------------------------
    template <typename score_functor>
    void apply( std::vector<int>&PaVar, std::vector<score_functor>& DegCount) {        
        std::vector<data_type>PaVarState;
        std::vector<int>XiVar;
        std::vector<data_type>XiVarState;
        bool ShowAll=0;        
        MainAlgorithmAARS(PaVar, PaVarState, XiVar, XiVarState, DegCount,ShowAll) ;   
    
    } // Call "apply" Function When Parent Variable Set or Child Variable Set is provided and all instances are not required.
    template <typename score_functor>
    void apply( std::vector<int>&PaVar, std::vector<score_functor>& DegCount, const bool& ShowAll) {        
        std::vector<data_type>PaVarState;
        std::vector<int>XiVar;
        std::vector<data_type>XiVarState;        
        MainAlgorithmAARS(PaVar, PaVarState, XiVar, XiVarState, DegCount,ShowAll) ;    
    } // Call "apply" Function When Parent Variable Set or Child Variable Set is provided and all instances are required.
    template <typename score_functor>
    void apply( std::vector<int>& PaVar,std::vector<data_type>& PaVarState, std::vector<score_functor>& DegCount) {        
        std::vector<int>XiVar;
        std::vector<data_type>XiVarState;        
        bool ShowAll=0;
        MainAlgorithmAARS(PaVar, PaVarState, XiVar, XiVarState, DegCount,ShowAll) ;    
    } // Call "apply" Function When Parent Variable Set and its respective states Set are provided.

    template <typename score_functor>
    void apply( int& singlePaVar, int& singleXiVar, std::vector<score_functor>& DegCount) {
	std::vector<int> PaVar; PaVar.push_back(singlePaVar);
	std::vector<int> XiVar; XiVar.push_back(singleXiVar);
        std::vector<data_type>PaVarState;        
        std::vector<data_type>XiVarState;
        bool ShowAll=0;
        MainAlgorithmAARS(PaVar, PaVarState, XiVar, XiVarState, DegCount,ShowAll) ;
    
    } // Call "apply" Function When both Parent Variable Set and Child Variable Set are provided and all instances are not required.

    template <typename score_functor>
    void apply( std::vector<int>& PaVar, std::vector<int>& XiVar, std::vector<score_functor>& DegCount) {
        std::vector<data_type>PaVarState;        
        std::vector<data_type>XiVarState;
        bool ShowAll=0;
        MainAlgorithmAARS(PaVar, PaVarState, XiVar, XiVarState, DegCount,ShowAll) ;
    
    } // Call "apply" Function When both Parent Variable Set and Child Variable Set are provided and all instances are not required.

    template <typename score_functor>
    void apply( std::vector<int>& PaVar, std::vector<int>& XiVar, std::vector<score_functor>& DegCount,const bool& ShowAll) {
        std::vector<data_type>PaVarState;        
        std::vector<data_type>XiVarState;
        MainAlgorithmAARS(PaVar, PaVarState, XiVar, XiVarState, DegCount,ShowAll) ;    
    } // Call "apply" Function When both Parent Variable Set and Child Variable Set are provided and all instances are required.
    
    template <typename score_functor>
    void apply( std::vector<int>& PaVar, std::vector<data_type>& PaVarState, std::vector<int>& XiVar, std::vector<data_type>& XiVarState, std::vector<score_functor>& DegCount) {         
        bool ShowAll=0;
        MainAlgorithmAARS(PaVar, PaVarState, XiVar, XiVarState, DegCount,ShowAll) ;       
    } // Call "apply" Function When both Parent Variable Set, its state set and Child Variable Set, its state set are provided.
    //----------------------------------------------------------------------------
private:
    template <int M, typename data_type_copy, typename Iter>
    friend AARSCounter <M, data_type_copy> create_AARSCounter(int n, int m, Iter it); // This function is called for building the Archive form the given dataset.
    //--------------------------------------------------------------------------------------
    
    template <typename score_functor>
    void MainAlgorithmAARS(std::vector<int>& PaVar,std::vector<data_type>& PaVarState, std::vector<int>& XiVar, std::vector<data_type>& XiVarState, std::vector<score_functor>& DegCount,const bool& ShowAll){
        int PaSize=PaVar.size(); 
        std::vector<int> CPno ; CPno.resize(PaSize);    // this vector stores number of consecutive parent variables in a group.
        std::vector<pair_int>Reorder;                   // this vector is for tracking order of the parent variable for optimizing.
        std::vector<pair_int>wo_bracket;                // this vertor stores first index of first element and number of elements in a buckets.
        std::vector<int>row_id;                         // This vector stores row indices of the datasets for each partition or bucket.   
        CPno= Consecutive_Parent_Searching(PaVar,PaSize,PaVarState,CPno,DegCount);              // Call Consecutive Parent Search (CPaS) for finding  consecutive groups of parent variables in the given parent variable set.
        Existence_Check_Archive( PaVar, PaSize, PaVarState, CPno,  DegCount);                   // call  Existence Check Archive (ECA) for checking whether Buckets of parent variable of group of consecutive parent variables are 
                                                                                                //archived in the Archived. If not archived then make partitions and saved found buckets in the Archive.
        Reorder=Parent_Order(PaVar,PaSize,CPno,DegCount);                                       //Call Parent Order for reordering based on number of buckets.
        PartitionCal(PaVar, PaVarState, PaSize, CPno, Reorder, wo_bracket, row_id,DegCount);    // Call PartitionCal for making partition of the dataset based on parent variable set.
        CountCal(PaVar, PaVarState, XiVar, XiVarState, wo_bracket, row_id, DegCount, ShowAll ); // call CountCal for calculating the total number of all instances of parent variable set
                                                                                                // and also calculate count for Child variable by further partition of found buckets of parent variable set based on child variable set.
    }// This is our proposed Adaptive archive radix strategy (AARS) approach which calls subfuncionts
    
    // Consecutive Parent Search (CPaS) function make groups of consecutive parent variables given consecutive constraint for storing and retrieving partitioned buckets.
    template <typename score_functor>
    std::vector<int> Consecutive_Parent_Searching(std::vector<int>& PaVar,const int& PaSize,std::vector<data_type>& PaVarState,std::vector<int>& CPno, std::vector<score_functor>& DegCount){
        if (PaSize==0){return CPno ;}
        if (PaSize==1){return CPno ;}
        if (!PaVarState.empty()){ return CPno;}                                                 // This block works only when states of parent variable set is given and does not make group
                                                                                                // as consecutiveness searching is not required when states are given.    
        std::sort(PaVar.begin(),PaVar.end());                                                   // Here required sorting parent variables to find consecutiveness.
        int pcount=0,p=0; int cpc=0;                                                            // Initialization for making groups of consecutive parent variables and  cpc is consecutive constraint variable.                                                                      //
        for(int p1=1;p1<PaSize;++p1){
            if(PaVar[p1]==PaVar[p1-1]+1){pcount+=1; continue;}                                  // Here checking consecutiveness.
            if (pcount>cpc){CPno[p]= pcount;p=p + pcount + 1; pcount=0;}                        // updating number of consecutive parent variables.
            else{p=p1;pcount=0;}            
        }
        if (pcount>cpc){CPno[p]= pcount;}                                                       // make group if only satisfy consecutive constraint.
        return CPno;
    }
    // Existence Check Archive algorithm of AARS approach
    template <typename score_functor>
    void Existence_Check_Archive(std::vector<int>& PaVar,const int& PaSize,std::vector<data_type>& PaVarState,std::vector<int>& CPno, std::vector<score_functor>& DegCount){
        if (PaSize==0 ||PaSize==1){return;}                                                     // If parent variable set containts empty or one variable only then not required to check Archive.
        if (!PaVarState.empty()){return;}                                                       // Same as parent set variable having states.
        for(int p2=0;p2<PaSize;){
            if(CPno[p2]==0){p2+=1;continue;}
            int ind=((n_*(n_+1))/2)-(((n_-PaVar[p2])*(n_-PaVar[p2]+1)/2))+CPno[p2];
            if(Aindx[ind]+wb_size[ind]!=-1){p2+=CPno[p2]+1;continue;}                           // Checking existance of buckets in archive here.
            else
            {                                                                                   // Checking existance of total number consecutive parent variables' buckets are stored in the Archive 
                int p4=0;
                for(int p3=1;p3<=CPno[p2];++p3) {
                    ind=((n_*(n_+1))/2)-(((n_-PaVar[p2])*(n_-PaVar[p2]+1)/2))+p3;
                    if(Aindx[ind]+wb_size[ind]!=-1){continue;}
                    else {p4=p3;break;}
                }
            //---------------------------------------------------------------                   // If not stored then make partition and stores those buckets in the archive.
                std::vector<int> row_id;
                std::vector<pair_int> ro_bracket;
                std::vector<pair_int> wo_bracket;
                Rxi.clear();
                Rxi.resize(max_r+1);
                ind=((n_*(n_+1))/2)-(((n_-PaVar[p2])*(n_-PaVar[p2]+1)/2))+p4-1;                 // Calculating index value of Aindx to find respective archive index.
                if(Aindx[ind]+wb_size[ind]==-2){
                    for(;p4<=CPno[p2];++p4){
                        Aindx[ind]=-1; wb_size[ind]=-1;
                        ind+=1;
                    }
                    wo_bracket.clear();row_id.clear();
                    p2+=CPno[p2]+1;
                    continue;
                }
                int tc=Aindx[ind]; row_id.clear();                                              // Decompressed the row index of the dataset for respective buckets stored in the Archive.
                for(int tc1=tc;tc1<tc+wb_size[ind];++tc1){
                    wo_bracket.push_back(A_wo_Br[tc1]);                                         
                    for(int uc=0 ; uc< ARid[tc1][ARid[tc1].size()-1]; uc=uc+3){                 
                        int cRowId= ARid[tc1][uc];
                        row_id.push_back(cRowId);
                        for(int uc1=1 ; uc1< ARid[tc1][uc+2]; uc1++){
                            cRowId= cRowId+ ARid[tc1][uc+1] ;
                            row_id.push_back(cRowId);
                        }
                    }
                    for(int uc=ARid[tc1][ARid[tc1].size()-1] ; uc< ARid[tc1].size()-1 ; uc=uc+1){
                        row_id.push_back(ARid[tc1][uc]);
                    }           
                }                                                                               // Decompression is done here

                for(;p4<=CPno[p2];++p4){
                    ro_bracket.clear();
                    ro_bracket.swap(wo_bracket);
                    int paInd = PaVar[p2]+p4;
                    int maxR=max_r; int paArity=-1;
                    DataPartitioningBasedOnParents(paInd, maxR, Dtemp_, paArity, wo_bracket, ro_bracket, row_id,DegCount);  // Calling partition function  
                    ind=((n_*(n_+1))/2)-(((n_-PaVar[p2])*(n_-PaVar[p2]+1)/2))+p4;
                    if (wo_bracket.empty()){
                        for(;p4<=CPno[p2];++p4){
                            Aindx[ind]=-1;wb_size[ind]=-1;row_id.clear();
                            ind+=1;
                        }
                        break;
                    }
                    Aindx[ind]=A_wo_Br.size();                                                                              // Storing partitioned buckets starts here.
                    int wbsize=wo_bracket.size(), ARidxsize=Aindx[ind];
                    wb_size[ind]=wbsize;
                    ARid.resize(ARidxsize+wbsize);
                    for(auto& val: wo_bracket){
                        A_wo_Br.push_back(val);
                        //row_id compression start here 
                        int firstInd=val.first; int lastInd=val.second;            
                        std::vector<int> row_id_c = RowIdCompression(firstInd, lastInd, row_id, DegCount);
                        ARid[ARidxsize].insert(ARid[ARidxsize].end(),row_id_c.begin(),row_id_c.end()); row_id_c.clear();                   
                        ++ARidxsize;
                    }                                                                                                       // finish the storing bucket's elements here
                }
            }
            p2+=CPno[p2]+1;
        }
        return;
    }

//  Ordering  parent variables based on number of buckets.
    template <typename score_functor>
    std::vector<pair_int> Parent_Order(std::vector<int>& PaVar,const int& PaSize,std::vector<int>& CPno, std::vector<score_functor>& DegCount){
        std::vector<pair_int> Reorder; Reorder.reserve(PaSize);
        if (PaSize==0){return Reorder;}
        bool need_order=0;
        for(auto& val:CPno){
            if (val>0){need_order=1;break;}
        }

        for(int p5=0;p5<PaSize;){
            //if(CPno[p5]<0){continue;}
            int ind=((n_*(n_+1))/2)-(((n_-PaVar[p5])*(n_-PaVar[p5]+1)/2))+CPno[p5];
            Reorder.push_back({wb_size[ind],p5});p5+=CPno[p5]+1;
        }

        if(need_order){
            std::sort(Reorder.begin(),Reorder.end(),[](std::pair<int, int> const& lhs, std::pair<int, int> const& rhs)
                {
                return lhs.first  > rhs.first ;
                }
            );
        }
        return Reorder;
    }   

    // This function is for partitioning the data into buckets depending on parent variables.
    template <typename score_functor>
    void PartitionCal(std::vector<int>& PaVar, std::vector<data_type>& PaVarState,const int& PaSize, std::vector<int>& CPno, std::vector<pair_int>& Reorder,std::vector<pair_int>& wo_bracket,std::vector<int>& row_id, std::vector<score_functor>& DegCount){
        std::vector<pair_int> ro_bracket;
        if (PaSize==0){wo_bracket.clear();return;}
        if (PaSize==1 ){            
            int p6=0; int paArity=-1;
            if(!PaVarState.empty()){paArity=PaVarState[p6];}
            BucRetFromArchAndDecompressed(p6,PaVar, paArity, CPno, Reorder,wo_bracket,row_id,DegCount);           // Calling this module to retrieve buckets and decompress its  elements.
            return;
        }

        int p6=0; int paArity=-1;
        if(!PaVarState.empty()){paArity=PaVarState[p6];}
        BucRetFromArchAndDecompressed(p6,PaVar, paArity, CPno, Reorder,wo_bracket,row_id,DegCount);
        if(!PaVarState.empty()){wo_bracket.pop_back();wo_bracket.push_back({0,row_id.size()});}
        
        for(int p7=1;p7<Reorder.size();++p7){
            if(CPno[Reorder[p7].second]==0){                                                                       // This block works when parent variables are not consecutive.
                Rxi.clear();
                Rxi.resize(max_r+1);
                ro_bracket.clear();
                ro_bracket.swap(wo_bracket);
                //int ind=((n_*(n_+1))/2)-(((n_-PaVar[Reorder[p7].second])*(n_-PaVar[Reorder[p7].second]+1)/2));
                int paInd = PaVar[Reorder[p7].second]; int maxR=max_r; int paArity=-1;
                if (!PaVarState.empty()){paArity= PaVarState[Reorder[p7].second]; }            
                DataPartitioningBasedOnParents(paInd, maxR, Dtemp_,paArity,wo_bracket,ro_bracket,row_id,DegCount);
            }
            else                                                                                                   // This block works when buckets of group of consecutive parent variable needs to retrived.
            {
                if(Reorder[p7].first < 0){wo_bracket.clear();row_id.clear(); return;}
                Rxi.clear();
                Rxi.resize(Reorder[p7].first);ro_bracket.clear();
                Dtemp1_.assign(m_,-1);                                                                             // Additional Dtemp1_ vector of size m_ is required to create for partioning buckets of first group
                std::vector<int>row_id_copy;row_id_copy.clear(); int paArity=-1;                                   // based on second group of consecutive parent variables.
                BucRetFromArchAndDecompressed(p7,PaVar, paArity, CPno, Reorder,ro_bracket,row_id_copy,DegCount);   
                int r=0;
                for(auto& val:ro_bracket){                                                                         // reassigned arity based on number of buckets of second group. 
                    for(int i= val.first;i<val.first+val.second;++i){Dtemp1_[row_id_copy[i]]=r;}
                    r=r+1;
                }
                                                                                                                   //  then partition the buckets further.
                row_id_copy.clear();
                ro_bracket.clear();
                ro_bracket.swap(wo_bracket);
                int paInd=0; int maxR = r ; 
                DataPartitioningBasedOnParents( paInd, maxR, Dtemp1_,paArity,wo_bracket,ro_bracket,row_id, DegCount);                
            }

        }
        Dtemp1_.clear();Rxi.clear();
        return ;
    } 

    // This function module is  for enumaring counts. It does further partitioning the buckets of parent variable set found from PartionCal module based on given child variable set and enumaret child count.
    template <typename score_functor>
    void CountCal(std::vector<int>& PaVar,std::vector<data_type>& PaVarState, std::vector<int>& XiVar,std::vector<data_type>& XiVarState,std::vector<pair_int>& wo_bracket,std::vector<int>& row_id, std::vector<score_functor>& DegCount,const bool& ShowAll ){
        int PaSize = PaVar.size();
        // calculation of total number of combination of parent valriables.
        long long int q = 1;
        for (int qpai=0;qpai<PaSize;++qpai){
            q= q* r_[PaVar[qpai]];
            if (q > std::numeric_limits<int>::max()){ q=std::numeric_limits<int>::max();}
        }
        q= static_cast<int>(q);
        //------------------------------------------------
        
        if(!PaVar.empty() && !PaVarState.empty() && XiVar.empty() && wo_bracket.empty()){   // this block works when parent variable set  and its element's state are present but buckets are empty.
            int Nij=0,Nijk=0; 
                DegCount[0].init(0,q);
                DegCount[0](Nij);DegCount[0](Nijk,Nij);
                DegCount[0].finalize(q,m1);             
            return;
        }
        if(!PaVar.empty() && !PaVarState.empty() && !XiVar.empty() && wo_bracket.empty()){ // this block works when parent variable set  and its element's state and child variable set are present but buckets are empty.
            int Nij=0,Nijk=0; 
            for(int i=0;i<XiVar.size();i++){
                DegCount[i].init(0,q);
                DegCount[i](Nij);DegCount[i](Nijk,Nij);
                DegCount[i].finalize(q,m1); 
            }
            return;
        }
        if(!PaVar.empty() && !PaVarState.empty() && XiVar.empty() && !wo_bracket.empty()){ // this block works when parent variable set  and its element's state are present and its buckets also present.
            int Nij=0,Nijk=0;            
                for(int i=0;i<row_id.size(); ++i ){
                    Nij=Nij+deg[row_id[i]];                                                // calculating to number of instances are present in the dataset for parent variable set.
                } 
            DegCount[0].init(0,q); DegCount[0](Nij);DegCount[0].finalize(q,m1); 
            return;
        }        
        

        if(!PaVar.empty() && !PaVarState.empty() && !XiVar.empty()&& !XiVarState.empty()){ // this block works when parent variable set and childe set and its element's state are present.                       
            for(int i=0;i<XiVar.size();i++){
                DegCount[i].init(0,q);
                int Nij=0; int Nijk=0;                            
                                  
                for(int ii=0;ii<row_id.size(); ++ii ){
                    Nij=Nij+deg[row_id[ii]];
                    int temp = Dtemp_[XiVar[i] * m_ + row_id[ii]];
                    if(XiVarState[i]==temp){Nijk=Nijk+deg[row_id[ii]];} 
                }
                
                DegCount[i](Nij);DegCount[i](Nijk,Nij);
                DegCount[i].finalize(q,m1);
            }
            return;
        }

        if(!PaVar.empty() && PaVarState.empty()  && XiVar.empty()&& XiVarState.empty()){  // this block works when parent variable set  and child variable set are present and required to enumarate all of them are present in the dataset.
            
            if (ShowAll){
                DegCount[0].init(0,q);
                std::vector<int>ShowAllRow;ShowAllRow.resize(m_,0); int UniqueIdStart;
                for(auto& val: wo_bracket){
                    int Nij=0; 
                                     
                    for(int ii=val.first;ii<(val.first+val.second); ++ii ){
                        Nij=Nij+deg[row_id[ii]];
                        if(ShowAllRow[ii]){ShowAllRow[row_id[ii]]=ShowAllRow[ii];ShowAllRow[ii]=row_id[ii];}        // finding  unique row index of instances which is not present in buckets.
                        else {ShowAllRow[row_id[ii]]=ii+1;ShowAllRow[ii]=row_id[ii];}
                    }
                    DegCount[0](Nij);
                    UniqueIdStart=val.first+val.second;
                } 

               for(int ii=UniqueIdStart;ii<m_; ++ii ){
                    if(ShowAllRow[ii]){DegCount[0](deg[ii-1]);}
                    else {DegCount[0](deg[ShowAllRow[ii]]);}
                }
               ShowAllRow.clear(); DegCount[0].finalize(q,m1);
               return;                 
            }

            if(wo_bracket.empty()){
                DegCount[0].init(0,q);
                for(int ii=0;ii<m_; ++ii ){DegCount[0](deg[ii]);}
                DegCount[0].finalize(q,m1);
                return;
            }

            for(auto& val: wo_bracket){
                int Nij=0; DegCount[0].init(0,q);                             
                for(int ii=val.first;ii<(val.first+val.second); ++ii ){
                    Nij=Nij+deg[row_id[ii]];
                }
                DegCount[0](Nij);
                DegCount[0].finalize(q,m1);
            }
            return;
        }

        if(!PaVar.empty() && PaVarState.empty()  && !XiVar.empty() && XiVarState.empty()){ // this block works when parent variable set  and child variable set are present and required to enumarate all instances are present in the dataset.
            
            std::vector<int>ChildCount;
            if (ShowAll){
                if(wo_bracket.empty()){
                    DegCount[0].init(0,q);
                    for(int ii=0;ii<m_; ++ii ){DegCount[0](deg[ii]);DegCount[0](deg[ii],deg[ii]);}
                    DegCount[0].finalize(q,m1);
                    return;
                }
                
                for(int i=0;i<XiVar.size();++i){
                    ChildCount.clear(); DegCount[i].init(0,q);
                    std::vector<int>ShowAllRow;ShowAllRow.resize(m_,0); int UniqueIdStart;
                    for(auto& val: wo_bracket){
                        int Nij=0; ChildCount.resize(max_r+1,0);                                       
                        for(int ii=val.first;ii<(val.first+val.second); ++ii ){
                            Nij=Nij+deg[row_id[ii]];
                            int temp = Dtemp_[XiVar[i] * m_ + row_id[ii]];
                            ChildCount[temp]= ChildCount[temp]+deg[row_id[ii]];                            
                            if(ShowAllRow[ii]){ShowAllRow[row_id[ii]]=ShowAllRow[ii];ShowAllRow[ii]=row_id[ii];}  // finding  unique row index of instances which is not present in buckets.
                            else {ShowAllRow[row_id[ii]]=ii+1;ShowAllRow[ii]=row_id[ii];}
                        }
                        DegCount[0](Nij);
                        for(int ii=0;ii<ChildCount.size(); ++ii ){
                            if(ChildCount[ii]!=0) { DegCount[i](ChildCount[ii],Nij);} 
                        }                                                        
                        ChildCount.clear();
                        UniqueIdStart=val.first+val.second;
                    } 
                    for(int ii=UniqueIdStart;ii<m_; ++ii ){
                        if(ShowAllRow[ii]){DegCount[i](deg[ii-1]);DegCount[i](deg[ii-1],deg[ii-1]);}
                        else {DegCount[i](deg[ShowAllRow[ii]]);DegCount[i](deg[ShowAllRow[ii]], deg[ShowAllRow[ii]]);}
                    }
                    ShowAllRow.clear(); DegCount[i].finalize(q,m1);
                }
                return;                 
            }

            if(wo_bracket.empty()){
                DegCount[0].init(0,q);
                for(int ii=0;ii<m_; ++ii ){DegCount[0](deg[ii],deg[ii]);}
                DegCount[0].finalize(q,m1);
                return;
            }

            for(int i=0;i<XiVar.size();++i){
                ChildCount.clear(); DegCount[i].init(0,q);
                for(auto& val: wo_bracket){
                    int Nij=0; 
                    ChildCount.resize(max_r+1,0);                 
                    for(int ii=val.first;ii<(val.first+val.second); ++ii ){
                        Nij=Nij+deg[row_id[ii]];
                        int temp = Dtemp_[XiVar[i] * m_ + row_id[ii]];
                        ChildCount[temp]= ChildCount[temp] + deg[row_id[ii]];
                    }
                    DegCount[i](Nij);
                    for(int ii=0;ii<ChildCount.size(); ++ii ){
                        if(ChildCount[ii]!=0) { DegCount[i](ChildCount[ii],Nij);} 
                    }                                                        
                    ChildCount.clear();
                }
                DegCount[i].finalize(q,m1);                      
            }
            return;
        }
    }
    
    // This function module is for retrieving buckets and decompress the bucket's elements.
     template <typename score_functor>
    void BucRetFromArchAndDecompressed(int& p6,std::vector<int>& PaVar, int& PaArity, std::vector<int>& CPno, std::vector<pair_int>& Reorder,std::vector<pair_int>& wo_bracket,std::vector<int>& row_id, std::vector<score_functor>& DegCount){
        int ind=((n_*(n_+1))/2)-(((n_-PaVar[Reorder[p6].second])*(n_-PaVar[Reorder[p6].second]+1)/2))+CPno[Reorder[p6].second];
        int tc=Aindx[ind];
        if(Aindx[ind]+wb_size[ind]==-2){wo_bracket.clear();row_id.clear(); return;}
        for(int tc1=tc;tc1<tc+wb_size[ind];++tc1){ 
            if (PaArity!=-1){
                int temp = Dtemp_[(PaVar[Reorder[p6].second]) * m_ + ARid[tc1][0]];
                if (temp==PaArity){wo_bracket.push_back(A_wo_Br[tc1]);}
                else {continue;}                    
            }
            else
            {wo_bracket.push_back(A_wo_Br[tc1]);}
            for(int uc=0 ; uc< ARid[tc1][ARid[tc1].size()-1]; uc=uc+3){
                int cRowId= ARid[tc1][uc];
                row_id.push_back(cRowId);
                for(int uc1=1 ; uc1< ARid[tc1][uc+2]; uc1++)
                {
                    cRowId= cRowId+ ARid[tc1][uc+1] ;
                    row_id.push_back(cRowId);
                }
            }
            for(int uc=ARid[tc1][ARid[tc1].size()-1] ; uc< ARid[tc1].size()-1 ; uc=uc+1){
                row_id.push_back(ARid[tc1][uc]);
            }             
        }
        return;            
    }

    // This module is for compressing bucket's elements to store compressed elements in the archive.
    template <typename score_functor>
    std::vector<int> RowIdCompression(const int& firstInd,const int& lastInd,const std::vector<int>& row_id, std::vector<score_functor>& DegCount){
                        //row_id compression start here
                std::vector<int> RowCompressed; RowCompressed.resize(3);
                std::vector<int> RowNotCompressed; std::vector<int> row_id_c;std::vector<int> row_id_b; 
                for (int i = firstInd; i < (lastInd+firstInd); i++)
                {
                    row_id_b.push_back(row_id[i]);
                }
                std::sort(row_id_b.begin(),row_id_b.end());
                int rcomp=0;
                while(rcomp<row_id_b.size()){
                    RowCompressed[0]= row_id_b[rcomp];
                    RowCompressed[1]= row_id_b[rcomp+1]-row_id_b[rcomp];
                    RowCompressed[2]=1;
                    while(++rcomp<row_id_b.size()){
                        if((row_id_b[rcomp]-row_id_b[rcomp-1])==RowCompressed[1])
                        {
                            RowCompressed[2]=RowCompressed[2]+1;
                        }
                        else
                        {
                            break;
                        }
                    }
                    if(RowCompressed[2]>2)
                        {
                            row_id_c.insert(row_id_c.end(),RowCompressed.begin(),RowCompressed.end());
                        }
                    else
                    {
                        int rnc_id=RowCompressed[0];
                        RowNotCompressed.push_back(rnc_id);
                        for (int rnc=1; rnc< RowCompressed[2];rnc++){
                            rnc_id=rnc_id+ RowCompressed[1];
                            RowNotCompressed.push_back(rnc_id);
                        }
                    }
                }
            rcomp=row_id_c.size();
            row_id_c.insert(row_id_c.end(),RowNotCompressed.begin(),RowNotCompressed.end());
            row_id_c.push_back(rcomp);RowNotCompressed.clear();row_id_b.clear();
            return row_id_c;
    }

    // This module is only used for partitoning  our newly gnerated data which is integer type .
    template <typename score_functor>
    void DataPartitioningBasedOnParents(const int& paInd, const int& maxR, const std::vector<int>& tempData, const int& paArity,std::vector<pair_int>& wo_bracket,std::vector<pair_int>& ro_bracket,std::vector<int>& row_id, std::vector<score_functor>& DegCount){
        int idx=0, i = 0; Rxi.resize(maxR);
        for (auto& val : ro_bracket) {
            if(val.second==1){continue;}
            for (int ii = val.first; ii < val.first + val.second; ++ii) {
                int temp = tempData[paInd * m_ + row_id[ii]];
                if(temp==-1){continue;}
                if(paArity!=-1){
                    if(temp==paArity){Rxi[temp].push_back(row_id[ii]);continue;}
                    else {continue;}
                }
                Rxi[temp].push_back(row_id[ii]);
            }

            for (int rx=0; rx<maxR; ++rx){
                if(paArity!=-1)
                {
                    if (Rxi[rx].empty()){Rxi[rx].clear();continue;}
                }
                else
                {
                    if (Rxi[rx].empty()||Rxi[rx].size()==1){Rxi[rx].clear();continue;}
                }
                for(int rid=0;rid<Rxi[rx].size();++rid){row_id[i++] = Rxi[rx][rid];}
                //for (auto& rid : Rxi[rx]) { row_id[i++] = rid; }
                wo_bracket.push_back({idx, Rxi[rx].size()});
                idx += Rxi[rx].size();
                Rxi[rx].clear();
            }
        }
        if (wo_bracket.empty()) {Rxi.clear(); row_id.clear(); return; }
        for (int i = row_id.size() - (wo_bracket.back().second + wo_bracket.back().first); i > 0; --i) {
            row_id.pop_back();
        }
        return;
    }

    // This module is only used for partitoning  buckets based on provided dataset which is data type .
    template <typename score_functor>
    void DataPartitioningBasedOnParents(const int& paInd, const int& maxR, const std::vector<data_type>& tempData, const int& paArity,std::vector<pair_int>& wo_bracket,std::vector<pair_int>& ro_bracket,std::vector<int>& row_id, std::vector<score_functor>& DegCount){
        int idx=0, i = 0;
        for (auto& val : ro_bracket) {
            if(val.second==1){continue;}
            for (int ii = val.first; ii < val.first + val.second; ++ii) {
                int temp = tempData[paInd * m_ + row_id[ii]];
                if(temp==-1){continue;}
                if(paArity!=-1){
                    if(temp==paArity){Rxi[temp].push_back(row_id[ii]);continue;}
                    else {continue;}
                }
                Rxi[temp].push_back(row_id[ii]);
            }

            for (int rx=0; rx<=maxR; ++rx){
                if(paArity!=-1)
                {
                    if (Rxi[rx].empty()){Rxi[rx].clear();continue;}
                }
                else
                {
                    if (Rxi[rx].empty()||Rxi[rx].size()==1){Rxi[rx].clear();continue;}
                }
                for(int rid=0;rid<Rxi[rx].size();++rid){row_id[i++] = Rxi[rx][rid];}
                //for (auto& rid : Rxi[rx]) { row_id[i++] = rid; }
                wo_bracket.push_back({idx, Rxi[rx].size()});
                idx += Rxi[rx].size();
                Rxi[rx].clear();
            }
        }
        if (wo_bracket.empty()) {Rxi.clear(); row_id.clear(); return; }
        for (int i = row_id.size() - (wo_bracket.back().second + wo_bracket.back().first); i > 0; --i) {
            row_id.pop_back();
        }
        return;
    }
    //--------------------------------------------------------------------------------------
    // Vectors and variables declarations
    int n_;                                                                                  // n_ is total number of variable.
    int m_;                                                                                  // m_ is number of rows of newly compressed dataset. 
    int m1;                                                                                  // m1 is number of rows of original dataset. 
    //-----------------------------------------------------------------------------------------------
    std::vector<data_type> Dtemp_;                                                           // To store compressed data of orginal dataset.
    std::vector<int> Dtemp1_;                                                                // This for creating new data for partitioning.
    std::vector<int> deg;                                                                    // This vector stores number of duplicate of a instance in the dataset.
    std::vector<int> r_;                                                                     // This vector stores total number of arity of all variables.
    int max_r;                                                                               // Maximum number of arity over all variables.
    std::vector<std::vector<int>> Rxi;                                                       // 2D array for partioning buckets.
    // Archive Elements declaration.
    std::vector<pair_int> A_wo_Br;                                                           //  A pair vector for storing buckets. It is part of the archive.
    std::vector<int> wb_size;                                                                //  This vector is for storing bucket size. It is also part of archive
    std::vector<std::vector<int>> ARid;                                                      // This array stores comppressed bucket's elements. Which is row number or instances id.
    std::vector<int> Aindx;                                                                  //  This vector stores indeces of the Archive.
    //-----------------------------------------------------------------------------------------------

}; // class AARSCounter

// This function module make suitable formate of the dataset  for AARS approach.
template <int N, typename data_type = uint8_t, typename Iter>
AARSCounter<N, data_type> create_AARSCounter(int n, int m, Iter it) {
    AARSCounter<N, data_type> AARS;

        AARS.n_ = n;
        AARS.m_ = m;
        AARS.m1 = m;
        AARS.r_.resize(AARS.n_);
        AARS.Rxi.reserve(AARS.m_);

        std::vector<data_type> D1_;
        D1_.reserve(m*n);

        int max_r_ =-1;
        for (int i = 0; i < n * m; ++i, ++it){D1_.push_back(*it); max_r_ = std::max<int>(max_r_,*it);}          // storing values of the dataset.
        AARS.max_r=max_r_;
        std::vector<int> row_id;
        std::vector<std::pair<int, int>> ro_bracket;
        std::vector<std::pair<int, int>> wo_bracket;
        std::vector<std::vector<int>> Rxi(max_r_+1);
        row_id.reserve(m);
        ro_bracket.reserve(m);
        wo_bracket.reserve(m);
        for (int rx=0;rx<=max_r_;++rx){Rxi[rx].reserve(m);}

        for(int i=0;i<m;++i){Rxi[D1_[i]].push_back(i);}
        for (int rx=0,idx=0;rx<=max_r_;++rx){
            if (Rxi[rx].empty()){continue;}
        row_id.insert(row_id.end(),Rxi[rx].begin(),Rxi[rx].end());
        wo_bracket.push_back({idx,Rxi[rx].size()});
        idx+=Rxi[rx].size(); Rxi[rx].clear();
            }

        for(int j=1;j<n;++j){
            ro_bracket.clear();
            ro_bracket.swap(wo_bracket);
            int idx=0; int i=0;
            for (auto& val : ro_bracket) {
                for (int ii = val.first; ii < val.first + val.second; ++ii) {
                data_type temp = D1_[j * m + row_id[ii]];
                Rxi[temp].push_back(row_id[ii]);
                }

            for (int rx=0 ; rx<=max_r_; ++rx){
            if (Rxi[rx].empty()){continue;}
            for(int rid=0;rid<Rxi[rx].size();++rid){row_id[i++] = Rxi[rx][rid];}
            //for (auto& rid : Rxi[rx]) { row_id[i++] = rid; }
             wo_bracket.push_back({idx, Rxi[rx].size()});
             idx += Rxi[rx].size();
             Rxi[rx].clear();
            }

            }
        }
        AARS.m_= wo_bracket.size();
        AARS.Dtemp_.reserve(n*AARS.m_);
        AARS.Dtemp1_.reserve(n*AARS.m_);
        for(int j=0;j<n;++j){
            for (auto& val : wo_bracket) {
            data_type temp = D1_[j * m + row_id[val.first]];
            AARS.Dtemp_.push_back(temp);
            }
        }
    for (auto& val : wo_bracket) {AARS.deg.push_back(val.second);}

    AARS.Aindx.resize((AARS.n_*(AARS.n_+1))/2,-1);
    AARS.wb_size.resize((AARS.n_*(AARS.n_+1))/2);

    for(int XiVar=0;XiVar<n;++XiVar){
        auto min_max = std::minmax_element(AARS.Dtemp_.begin() + XiVar * AARS.m_, AARS.Dtemp_.begin() + (XiVar + 1) * AARS.m_);
        std::transform(AARS.Dtemp_.begin() + XiVar * AARS.m_, AARS.Dtemp_.begin() + (XiVar + 1) * AARS.m_, AARS.Dtemp_.begin() + XiVar * AARS.m_, [min_max](data_type x) { return x - *(min_max.first); } );
        AARS.r_[XiVar] = *min_max.second - *min_max.first + 1;
    }

    std::vector<int> RowCompressed; RowCompressed.resize(3);
    std::vector<int> RowNotCompressed;
    for (int XiVar = 0, r_sum = 0,ind=0,buks=0; XiVar < n; ++XiVar) {
        for (int rx=0;rx<=max_r_;++rx){Rxi[rx].clear();}
        row_id.clear();

        for(int i=0;i<AARS.m_;++i){Rxi[AARS.Dtemp_[XiVar*AARS.m_+i]].push_back(i);}
        wo_bracket.clear();
        for (int rx=0,idx=0;rx<=max_r_;++rx){
            if (Rxi[rx].empty()){continue;}
        //row_id compression start here
        int rcomp=0;
        while(rcomp<Rxi[rx].size()){
            RowCompressed[0]= Rxi[rx][rcomp];
            RowCompressed[1]= Rxi[rx][rcomp+1]-Rxi[rx][rcomp];
            RowCompressed[2]=1;
            while(++rcomp<Rxi[rx].size()){
                if((Rxi[rx][rcomp]-Rxi[rx][rcomp-1])==RowCompressed[1])
                {
                    RowCompressed[2]=RowCompressed[2]+1;
                }
                else
                {
                    break;
                }
            }
            if(RowCompressed[2]>2)
                {
                    row_id.insert(row_id.end(),RowCompressed.begin(),RowCompressed.end());
                }
            else
            {
                int rnc_id=RowCompressed[0];
                RowNotCompressed.push_back(rnc_id);
                for (int rnc=1; rnc< RowCompressed[2];rnc++){
                    rnc_id=rnc_id+ RowCompressed[1];
                    RowNotCompressed.push_back(rnc_id);
                }
            }
        }
        rcomp=row_id.size();
        row_id.insert(row_id.end(),RowNotCompressed.begin(),RowNotCompressed.end());
        row_id.push_back(rcomp);RowNotCompressed.clear();
        //
        //row_id.insert(row_id.end(),Rxi[rx].begin(),Rxi[rx].end());
        AARS.A_wo_Br.push_back({idx,Rxi[rx].size()});
        AARS.ARid.push_back({row_id});

        idx+=Rxi[rx].size(); Rxi[rx].clear(); row_id.clear();wo_bracket.clear();
        }
        ind = ((AARS.n_*(AARS.n_+1))/2)-(((AARS.n_-XiVar)*(AARS.n_-XiVar+1)/2));
        AARS.Aindx[ind]=r_sum; buks= AARS.A_wo_Br.size()- r_sum;
        r_sum= AARS.A_wo_Br.size();
        AARS.wb_size[ind]=buks;

    }
//------------------------------------------------------------------------------------------------

    return AARS;
} // create_AARSCounter

#endif // AARS_COUNTER_HPP
