#ifndef MODEL_FIT_HPP
#define MODEL_FIT_HPP

#include "graph_util.hpp"
#include "omp.hpp"


class estimator {
public:
    void init(int ri, int qi) { state_ = 0.0; }

    void finalize(int qi) { }

    void operator()(int Nij) { }

    void operator()(int Nijk, int Nij) { state_ = static_cast<double>(Nijk) / Nij; }

    double state() const { return state_; }

private:
    double state_ = 0.0;

}; // class estimator


template <int N, typename CQE>
inline std::pair<bool, std::string> mle(const CQE& cqe, const network_struct<N>& G, network_fitted<N>& fit) {
    int n = cqe.n();

    if (G.size() != n) return {false, "network and data mismatch"};

    // we allow for G to have .range missing (e.g., after reading SIF)
    fit.G = G;
    fit.P.resize(n);

    for (int xi = 0; xi < n; ++xi) { fit.G[xi].range = cqe.r(xi); }

    using data_type = typename CQE::data_type;
    using set_type = uint_type<N>;

    std::vector<estimator> pe(1);
    std::string message = "";

    #pragma omp parallel for firstprivate(pe)
    for (int xi = 0; xi < n; ++xi) {
        auto xi_set = set_empty<set_type>();
        xi_set = set_add(xi_set, xi);

        auto pa_vec = as_vector(G[xi].pa);

        int ri = fit.G[xi].range;
        int q = num_states(fit.G, pa_vec);

        fit.P[xi].resize(ri * q);

        int pos = 0;

        for (int j = 0; j < q; ++j) {
            double S = 0.0;
            auto pa_state = var_states<data_type>(fit.G, j, pa_vec);
            for (data_type i = 0; i < ri; ++i) {
                cqe.apply(xi_set, G[xi].pa, std::vector<data_type>{i}, pa_state, pe);
                fit.P[xi][pos++] = pe[0].state();
                S += pe[0].state();
            }
            // missing data, we assume (uninformative) uniform distribution
            if (S < 0.999) {
                #pragma omp critical
                message = "unable to estimate parameter, assuming uniform";
                for (data_type i = 0; i < ri; ++i) fit.P[xi][pos - i - 1] = (1.0 / ri);
            }
        } // for j
    } // for xi

    return {true, message};
} // mle

#endif // MODEL_FIT_HPP
