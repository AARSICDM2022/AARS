#!/bin/bash

rm -rf bin/
rm -rf build/

